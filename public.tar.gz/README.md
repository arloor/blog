# 博客
使用hugo生成静态博客

## 先安装hugo 0.53 （需要支持 scss）

## 部署
```
bash deploy.sh
````
这样就直接部署到了我的centos7服务器上

访问[arloor博客](http://arloor.com)